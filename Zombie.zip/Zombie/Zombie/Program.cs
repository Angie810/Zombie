﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;

namespace Zombie
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] loop = new int[10];

            for (int i = 0; i < 10; i++)
            {
                loop[i] = ZombieRun();
            }

            int sum = loop.Sum();
            int avg = sum / 10;
            Console.WriteLine(avg);
            Console.WriteLine($"The average rounds to turn all houseowners to zombies is {avg}");
        }
        private static int ZombieRun()
        {
            Random random = new Random();

            int loop = 0;
            const int numOfHouses = 100;
            int n = 1; //number of zombies
            int[,] houses = new int[10, 10];

            // Initialize houses
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    houses[i, j] = 1;
                }
            }

            // Loop until all houses have been changed to Zombies
            while (n < numOfHouses + 1)
            {
                loop++;
                Console.Clear();
                // Print current status of houses
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        if (houses[i, j] == 1)
                        {
                            Console.Write(" P ");
                            Console.ForegroundColor = ConsoleColor.Green;
                        }
                        else
                        {
                            Console.Write(" Z ");
                            Console.ForegroundColor = ConsoleColor.Red;
                        }
                    }
                    Console.WriteLine();
                }

                // Thread sleep 1s
                Thread.Sleep(1000);

                // Zombies attack
                int currentZombies = n;

                for (int i = 0; i < currentZombies; i++)
                {
                    int x = random.Next(0, 10);
                    int y = random.Next(0, 10);

                    if (houses[x, y] == 1)
                    {
                        n++;
                        houses[x, y] = 0;
                    }
                }
            }

            return loop;
        }
    }
}
